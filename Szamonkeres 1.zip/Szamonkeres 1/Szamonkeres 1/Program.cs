﻿using System;
using MySql.Data.MySqlClient;

namespace Szamonkeres_1
{
    class Program
    {
        static string connectionString =
            "server=localhost;database=auto;uid=root;pwd=;";

        static void Main(string[] args)
        {
            Console.WriteLine("1 - Autók ID + Brand listázása");
            Console.WriteLine("2 - Új autó hozzáadása");
            Console.WriteLine("3 - 123-as ID Date módosítása");
            Console.WriteLine("4 - 257-es ID törlése");
            Console.Write("Választás: ");

            int valasztas = int.Parse(Console.ReadLine());

            switch (valasztas)
            {
                case 1:
                    OsszesAutoLekerdez();
                    break;
                case 2:
                    UjAutoHozzaadas();
                    break;
                case 3:
                    DatumModositas();
                    break;
                case 4:
                    AutoTorles();
                    break;
            }

            Console.ReadKey();
        }

        // 1️⃣ Összes autó ID + Brand
        static void OsszesAutoLekerdez()
        {
            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                conn.Open();

                string sql = "SELECT Id, Brand FROM cars";
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                MySqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    Console.WriteLine($"ID: {reader["Id"]}, Brand: {reader["Brand"]}");
                }
            }
        }

        // 2️⃣ Új autó hozzáadása
        static void UjAutoHozzaadas()
        {
            Console.Write("Brand: ");
            string brand = Console.ReadLine();

            Console.Write("Type: ");
            string type = Console.ReadLine();

            Console.Write("License: ");
            string license = Console.ReadLine();

            Console.Write("Date (év): ");
            int date = int.Parse(Console.ReadLine());

            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                conn.Open();

                string sql = @"INSERT INTO cars (Brand, Type, License, Date)
                               VALUES (@brand, @type, @license, @date)";

                MySqlCommand cmd = new MySqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@brand", brand);
                cmd.Parameters.AddWithValue("@type", type);
                cmd.Parameters.AddWithValue("@license", license);
                cmd.Parameters.AddWithValue("@date", date);

                cmd.ExecuteNonQuery();
                Console.WriteLine("Új autó sikeresen hozzáadva!");
            }
        }

        // 3️⃣ 123-as ID Date módosítása
        static void DatumModositas()
        {
            Console.Write("Új Date (év): ");
            int ujDate = int.Parse(Console.ReadLine());

            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                conn.Open();

                string sql = "UPDATE cars SET Date = @date WHERE Id = 123";
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@date", ujDate);

                cmd.ExecuteNonQuery();
                Console.WriteLine("Date frissítve!");
            }
        }

        // 4️⃣ 257-es ID törlése
        static void AutoTorles()
        {
            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                conn.Open();

                string sql = "DELETE FROM cars WHERE Id = 257";
                MySqlCommand cmd = new MySqlCommand(sql, conn);

                cmd.ExecuteNonQuery();
                Console.WriteLine("Autó törölve!");
            }
        }
    }
}